from django.apps import AppConfig


class CafeConfig(AppConfig):
    name = 'cafe'
