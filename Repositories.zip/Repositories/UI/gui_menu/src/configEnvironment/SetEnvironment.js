import React from 'react';

class SetEnvironment  extends React.Component{
        constructor(props) {
		super(props);
		// this.state = {host_IP : '10.151.201.35'};
	}
	static getHost_IP(){
		// return '10.151.240.123';
		return	'10.151.240.123';
	}
}

export default SetEnvironment;